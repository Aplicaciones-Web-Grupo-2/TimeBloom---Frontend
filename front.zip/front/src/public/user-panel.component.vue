<script>
export default {
  name: "user-panel"
}
</script>

<template>
 ESTADISTICAS DE USUARIO IRAN AQUI, usar sidebar
</template>

<style scoped>

</style>